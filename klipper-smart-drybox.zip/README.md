# Klipper Smart Drybox

A Klipper-controlled filament drybox with PID temperature control, humidity regulation, and material presets.

## Features
- PID-controlled heater for smooth temperature
- Humidity monitoring and fan control
- Material presets: PLA, PETG, Nylon
- Automatic drying loops and live status updates
- Mainsail dashboard integration

## Hardware
- Heater: Generic 3950 thermistor
- Temperature sensors: drybox center + humidity thermistor
- Fan: 12V PWM fan
- Optional: Raspberry Pi / ESP32 for control

## Usage
1. Copy configs/drybox.cfg to your Klipper config folder
2. Include macros in your START_PRINT / END_PRINT scripts
3. Restart Klipper: FIRMWARE_RESTART
4. Start drying:
   - DRY_PLA
   - DRY_PETG
   - DRY_NYLON
5. Stop drying: DRY_STOP
6. Check status: DRY_STATUS

## Notes
- PLA target temperature: 45°C
- PETG target temperature: 50°C
- Nylon target temperature: 60°C
- Humidity loop: every 10s
- Status updates: every 60s
