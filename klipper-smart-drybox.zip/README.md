# Klipper Smart Drybox
A Klipper-controlled filament drybox with PID temperature control, humidity regulation, and material presets.

## Features
- PID-controlled heater for smooth temperature
- Humidity monitoring and fan control
- Material presets: PLA, PETG, Nylon
- Automatic drying loops and live status updates
- Mainsail dashboard integration
